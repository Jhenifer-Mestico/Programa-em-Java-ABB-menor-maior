// Classe ABB para demonstrar a inserção, busca, remoção, atravessamentos etc.
// em uma Árvore Binária de Busca (ABB).
// Ledón, 2016/2017; Amilton Souza Martha, 2015/2017.

package testa_abb;

import java.util.LinkedList;
import java.util.Stack;

class ABB<E extends Comparable<E>> {  // Árvore Binária de Busca 

    private Node raiz;

    public ABB() {
        raiz = null;
    }

    public boolean isEmpty() {
        return (raiz == null);
    }

    //Configura a raiz da árvore
    public void setRaiz(Node araiz) {
        raiz = araiz;
    }

    public Node getRaiz() {
        return raiz;
    }

    public E inserir(E valor) {
        try {
            Node novo = new Node(valor);
            this.inserir(novo, raiz);
        } catch (Exception exMemoria) {
            return null;
        }   // memória insuficiente
        return (valor);
    }

    private Node inserir(Node novo, Node anterior) {
        if (raiz == null) {    // ou if(isEmpty())
            raiz = novo;  // ou setRaiz(novo);
            return raiz;
        }
        if (anterior == null) {
            return novo; // chegou em uma folha
        } else {
            if (novo.getValue().compareTo(anterior.getValue()) < 0) {
                anterior.setFilhoEsquerdo(inserir(novo, anterior.getFilhoEsquerdo()));
            } else {
                anterior.setFilhoDireito(inserir(novo, anterior.getFilhoDireito()));
            }
            return anterior;
        }
    }

    
    private int compara(Object ob1, Object ob2) {
        return ((Comparable) ob1).compareTo(((Comparable) ob2));
    }
    
   
    public void emOrdemInvertido(Node no) {
        Stack pilha = new Stack(); 
        Stack pilhaInvertida = new Stack();

        pilha.push(no);
        Node aux;

        while (true) {
            aux = (Node) pilha.pop();
            if (aux != null) {
                pilha.push(aux);
                pilha.push(aux.getFilhoEsquerdo());
            } else {
                if (pilha.empty()) {
                    break;
                }
                aux = (Node) pilha.pop();
                pilha.push(aux.getFilhoDireito());
                pilhaInvertida.push(aux);
            }
        }
        while (!pilhaInvertida.isEmpty()){
            Node noAux = (Node) pilhaInvertida.pop();
            System.out.print(noAux + "\n");
        }
    }
}