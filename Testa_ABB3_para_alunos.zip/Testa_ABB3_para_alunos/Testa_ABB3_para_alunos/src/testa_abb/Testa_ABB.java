// Classe ABB para demonstrar a inserção, busca, remoção, atravessamentos etc.
// em uma Árvore Binária de Busca (ABB).

// Ledón, 2016/2017; Amilton Souza Martha, 2015/2017.

package testa_abb;

public class Testa_ABB {

    public static void main(String[] args) {
        
        /*System.out.println("\n\nVamos criar uma ABB com objetos da classe Integer:\n");
        ABB abb1 = new ABB();*/
        
        System.out.println("\n\nAgora vamos criar uma ABB de objetos da classe Aluno (inserir pelos RGMs e percorrer em-ordem, do maior ao menor):\n");
        ABB abb2 = new ABB();
        Aluno alA = new Aluno("888-8", "Caio", 'M', 5.5f);
        Aluno alB = new Aluno("333-3", "Lara", 'F', 9.8f);
        Aluno alC = new Aluno("666-6", "Vanessa", 'F', 8.8f);
        Aluno alD = new Aluno("111-1", "Luiz", 'M', 6.5f);
        Aluno alE = new Aluno("999-9", "Ana", 'F', 9.5f);
        
        
        abb2.inserir(alA);
        abb2.inserir(alB);
        abb2.inserir(alC);
        abb2.inserir(alD);
        abb2.inserir(alE);
        
      
        abb2.emOrdemInvertido(abb2.getRaiz());
 
    }
   
}